#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 28 17:48:58 2019

@author: khitishmohanty
"""

import math
import rasterio
import matplotlib.pyplot as plt

image_file = "/Users/khitishmohanty/KK Docs/KK Documents/Khitish Mohanty/WorkSpace/Datathon2019/phase-01/data/sentinel-2a-tile-7680x-10240y/timeseries/7680-10240-TCI-2019-08-09.png"
sat_data = rasterio.open(image_file)

width_in_projected_units = sat_data.bounds.right - sat_data.bounds.left
height_in_projected_units = sat_data.bounds.top - sat_data.bounds.bottom

print("Width: {}, Height: {}".format(width_in_projected_units, height_in_projected_units))

print("Rows: {}, Columns: {}".format(sat_data.height, sat_data.width))

# Upper left pixel
row_min = 0
col_min = 0

# Lower right pixel.  Rows and columns are zero indexing.
row_max = sat_data.height - 1
col_max = sat_data.width - 1

# Transform coordinates with the dataset's affine transformation.
topleft = sat_data.transform * (row_min, col_min)
botright = sat_data.transform * (row_max, col_max)

print("Top left corner coordinates: {}".format(topleft))
print("Bottom right corner coordinates: {}".format(botright))

print(sat_data.count)

# sequence of band indexes
print(sat_data.indexes)

# Displaying the blue band.
b, g, r = sat_data.read()

fig = plt.imshow(b)
plt.show()


# Displaying the green band.

fig = plt.imshow(g)
fig.set_cmap('gist_earth')
plt.show()


# Displaying the red band.

fig = plt.imshow(r)
fig.set_cmap('inferno')
plt.colorbar()
plt.show()























