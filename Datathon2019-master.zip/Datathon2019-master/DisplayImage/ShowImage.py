# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 14:49:56 2019

@author: vicdxx4
"""

import cv2
def show_image(image):
    cv2.namedWindow(winname = "Resltant image", flags = cv2.WINDOW_NORMAL)
    cv2.imshow(winname = "Resltant image", mat = image)
    cv2.waitKey(delay = 0)