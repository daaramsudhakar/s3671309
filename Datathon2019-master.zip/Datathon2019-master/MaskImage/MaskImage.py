# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 14:44:40 2019

@author: vicdxx4
"""
import cv2
import numpy as np

def image_mask(image, mask):
    mask_1 = np.where(mask!=0, 255, mask)

    maskedImg = cv2.bitwise_and(src1 = image, src2 = mask_1)
    
    return maskedImg
