# -*- coding: utf-8 -*-
"""
Created on Thu Aug 22 14:00:28 2019

@author: vicdxx4
"""

def path_to_date(TimeSeriesData):
    TimeSeriesData = TimeSeriesData.ImagePaths.str.split("-",expand=True,)
    ColNames = TimeSeriesData.columns
    TimeSeriesData = TimeSeriesData[[ColNames[len(ColNames)-3], ColNames[len(ColNames)-2], ColNames[len(ColNames)-1]]]
    TimeSeriesData.columns = ['Year', 'Month', 'Date.png']
    DayData = TimeSeriesData['Date.png'].str.split(".",expand=True,)
    TimeSeriesData['Day'] = DayData[0]
    TimeSeriesData['Date'] = TimeSeriesData['Year'] + "-" + TimeSeriesData['Month'] + "-" + TimeSeriesData['Day']
    return TimeSeriesData['Date']