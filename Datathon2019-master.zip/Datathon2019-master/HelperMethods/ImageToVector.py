from PIL import Image
import numpy as np

def convert_image_to_vector(path):

    img = Image.open(path)#.convert('RGBA')
    
    return np.asanyarray(img).reshape(-1).tolist()
