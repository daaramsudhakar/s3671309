
import glob
import config

def get_timeseries_image_paths(tile_x, tile_y, band):
    path = config.SourceImageFolder + f"sentinel-2a-tile-{tile_x}x-{tile_y}y/timeseries/{tile_x}-{tile_y}-{band}*.png"
#    path = f"C:/Data/datathonData/data/sentinel-2a-tile-{tile_x}x-{tile_y}y/timeseries/{tile_x}-{tile_y}-{band}*.png"
    images = glob.glob(path)
    return images
