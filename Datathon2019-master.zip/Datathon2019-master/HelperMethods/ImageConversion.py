# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 12:07:16 2019

@author: vicdxx4
"""



import sys
sys.path.append("./ImageExploration")

from PIL import Image
import config

def png_to_tiff(ImagePath):
    ImageName = ImagePath.split("\\")[1]
    img = Image.open(ImagePath)
    DestinationPath = config.SourceImage_TIFF_Folder + "\\" + ImageName.split(".")[0] + "." + "tiff"    
    img.save(DestinationPath)
    return True 
