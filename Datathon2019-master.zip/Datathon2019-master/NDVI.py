#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 28 17:59:34 2019

@author: khitishmohanty
"""

import pandas as pd
import sys
sys.path.append("./ImageExploration")

from HelperMethods.ImageSelector import get_timeseries_image_paths
from HelperMethods.ImageConversion import png_to_tiff

#Gathering Oroginal Image
ImagePaths = get_timeseries_image_paths("7680", "10240", "TCI")

#Converting images into tiff format
ImagePathsDF = pd.DataFrame(ImagePaths)
ImagePathsDF.columns = ['ImagePath']
ImagePathsDF['ImageConversionFlag'] = ImagePathsDF['ImagePath'].apply(lambda text: png_to_tiff(text))

##############################################

import math
import rasterio
import matplotlib.pyplot as plt
import numpy as np
import cv2
from PIL import Image, ImageChops
from collections import Counter
import glob