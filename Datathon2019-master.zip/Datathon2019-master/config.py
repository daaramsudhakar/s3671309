# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 12:22:45 2019

@author: vicdxx4
"""

SourceImageFolder = "C:/Data/datathonData/data/"
SourceImage_TIFF_Folder = "C:\Data\datathonData\data\TIFF_Images"
