# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 12:59:09 2019

@author: vicdxx4
"""

import cv2
import numpy as np
import sys
sys.path.append("./ImageExploration")

from CompairImage.ImageDifference import image_difference
from MaskImage.MaskImage import image_mask
from DisplayImage.ShowImage import show_image
from HelperMethods.ImageSelector import get_timeseries_image_paths
###################################################################

#Master function
imageA = cv2.imread("C:/Data/DPC_BusinessInsights/Datathon2019/phase-01/data/sentinel-2a-tile-7680x-10240y/timeseries/7680-10240-TCI-2018-08-24.png")
imageB = cv2.imread("C:/Data/DPC_BusinessInsights/Datathon2019/phase-01/data/sentinel-2a-tile-7680x-10240y/timeseries/7680-10240-TCI-2018-09-03.png")
mask = cv2.imread(filename="C:/Data/DPC_BusinessInsights/Datathon2019/phase-01/data/sentinel-2a-tile-7680x-10240y/masks/sugarcane-region-mask.png")

maskedImg = image_mask(imageA, mask)
imageA, imageB, diff, thresh, SSIM = image_difference(imageA, imageB, "True")


#display Image
show_image(maskedImg)


###################################################################

#Experiments
imageA = cv2.imread("C:/Data/DPC_BusinessInsights/Datathon2019/phase-01/data/sentinel-2a-tile-7680x-10240y/timeseries/7680-10240-TCI-2018-08-14.png")
imageB = cv2.imread("C:/Data/DPC_BusinessInsights/Datathon2019/phase-01/data/sentinel-2a-tile-7680x-10240y/timeseries/7680-10240-TCI-2018-08-24.png")
imageC = cv2.imread("C:/Data/DPC_BusinessInsights/Datathon2019/phase-01/data/sentinel-2a-tile-7680x-10240y/timeseries/7680-10240-TCI-2018-09-03.png")

imageA, imageB, diff_1, thresh_1, SSIM_1 = image_difference(imageA, imageB, "False")
imageB, imageC, diff_2, thresh_2, SSIM_2 = image_difference(imageB, imageC, "False")


thresh = np.add(thresh_1, thresh_2)
thresh_km = np.where(thresh==254, 255, thresh)

cv2.imwrite('C:/Data/DPC_BusinessInsights/Datathon2019/ImageExploration/Output/imageA.png',imageA)
cv2.imwrite('C:/Data/DPC_BusinessInsights/Datathon2019/ImageExploration/Output/imageB.png',imageB)
cv2.imwrite('C:/Data/DPC_BusinessInsights/Datathon2019/ImageExploration/Output/imageC.png',imageC)
cv2.imwrite('C:/Data/DPC_BusinessInsights/Datathon2019/ImageExploration/Output/diff_1.png',diff_1)
cv2.imwrite('C:/Data/DPC_BusinessInsights/Datathon2019/ImageExploration/Output/diff_2.png',diff_2)
cv2.imwrite('C:/Data/DPC_BusinessInsights/Datathon2019/ImageExploration/Output/thresh_1.png',thresh_1)
cv2.imwrite('C:/Data/DPC_BusinessInsights/Datathon2019/ImageExploration/Output/thresh_2.png',thresh_2)
cv2.imwrite('C:/Data/DPC_BusinessInsights/Datathon2019/ImageExploration/Output/thresh_km.png',thresh_km)


####################################################################


ImagePaths = get_timeseries_image_paths("7680", "10240", "TCI")

thresh = np.zeros((512,512), dtype=np.uint8)
for i in range(len(ImagePaths)-1):
    Img_thresh = image_difference(cv2.imread(ImagePaths[i]), cv2.imread(ImagePaths[i+1]), "False")[3]
    thresh = np.add(thresh, Img_thresh)
    thresh_modified = np.where(thresh==254, 255, thresh)


show_image(thresh_modified)


##############latest#######################



















