
import pandas as pd
import sys
sys.path.append("./ImageExploration")

from HelperMethods.ImageSelector import get_timeseries_image_paths
from HelperMethods.ImageToVector import convert_image_to_vector
from HelperMethods.PathtoDate import path_to_date
 
TimeSeriesData = pd.DataFrame()

#Collecting the image paths
TimeSeriesData['ImagePaths'] = get_timeseries_image_paths("7680", "10240", "TCI")

#Extract the dates from the file path name
TimeSeriesData['Date'] = path_to_date(TimeSeriesData)

#Creating image vector
TimeSeriesData['ImageVector'] = TimeSeriesData['ImagePaths'].apply(lambda path: convert_image_to_vector(path))




#saving the dataframe
TimeSeriesData.to_csv("C:\Data\datathonData\Output\TimeSeriesData.csv")
TimeSeriesData.to_json("C:\Data\datathonData\Output\TimeSeriesData.json")